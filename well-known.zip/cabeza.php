<header>
        <div class="header_left">
		   	<div class="logo">
            <a href="index.php"><img src="images/logo.png" alt=""></a>
            <strong>Estudio Contable MTA + Asociados</strong>
            </div>
        </div>
        
        <div class="header_right">
        	<nav id="topmenu">            
	            <ul class="dropdown">
	                <li class="menu-item-home"><a href="index.php"><span>Portada</span></a></li>	                
	                <li><a href="#"><span>Contenido</span></a>
	                	<ul>
                        	<li><a href="about.php?c=1"><span>Ideología</span></a></li>	                    	
                        	<li><a href="about.php?c=2"><span>Misión</span></a></li>	                    	
                        	<li><a href="about.php?c=3"><span>Visión</span></a></li>
	                    </ul>
	                </li>
                    <li><a href="about.php?c=4"><span>Servicios</span></a>
	                	<ul>
							<li><a href="sf.php?c=6"><span>Sinceramiento fiscal</span></a></li>	         
                        	<li><a href="about.php?c=4"><span>Impuestos</span></a></li>	                    	
                        	<li><a href="about.php?c=4"><span>Contabilidad</span></a></li>	                    	
                        	<li><a href="about.php?c=4"><span>Sueldos y Previsional</span></a></li>	                    	
	                        <li><a href="about.php?c=4"><span>Sociedades</span></a></li>
	                        <li><a href="about.php?c=4"><span>Consultoria</span></a></li>
	                        <li><a href="about.php?c=4"><span>Jubilaciones y Pensiones</span></a></li>
	                    </ul>
	                </li>
	                <li><a href="about.php?c=5"><span>Herramientas</span></a></li>
	                <li><a href="clientes.php"><span>Clientes</span></a></li>
	                <li><a href="contact.php"><span>Contacto</span></a></li>
	            </ul>                
			</nav>
        	<!--/ topmenu -->
        </div>
        <div class="clear"></div>			    
	</header>